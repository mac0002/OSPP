#include <stdio.h>    // puts(), printf(), perror(), getchar()
#include <stdlib.h>   // exit(), EXIT_SUCCESS, EXIT_FAILURE
#include <unistd.h>   // getpid(), getppid(),fork()
#include <sys/wait.h> // wait()

#define READ  0
#define WRITE 1

void child_a(int fd[]) {

  // TODO: Add code here.

}

void child_b(int fd[]) {

  // TODO: Add code here.

}

int main(void) {
  int fd[2];

  // TODO: Add code here.

}
