# Processes and Inter Process Communication (IPC)

Assignments about: 

- Processes and process management
- Signals
- Pipes
