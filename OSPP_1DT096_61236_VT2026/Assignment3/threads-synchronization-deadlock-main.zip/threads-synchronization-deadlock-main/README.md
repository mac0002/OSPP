# Threads, synchronization and deadlock

Assignments about: 

- Threads
- Synchronization
- Deadlock

